function myfunction() {
    document.getElementById("part1").style.display = "none";
    document.getElementById("part2").style.display = "block";
}